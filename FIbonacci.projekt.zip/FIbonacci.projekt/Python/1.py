van_szam = True
print("Hany darab FIBONACCI szamot szeretnel generalni ( 1 - 100 ) ?")
while van_szam:
    fibonacci_szamok = []
    n = input("Darab: ")
    if not n.isdigit():
        print("HIBA: Az adatnak szamnak kell lennie ( 1 - 100 )!")
    else:
        darab = int(n)
        if darab > 100 or darab < 1:
            print("HIBA: A darabszam ( 1 - 100 ) legyen!")
        else:
            print("Rendben!")
            elozo = 1
            megelozo = 0
            for i in range(1, darab+1):
                akt = elozo + megelozo
                fibonacci_szamok.append(elozo)
                megelozo = elozo
                elozo = akt

            print(fibonacci_szamok)

            db = 0
            for sz in fibonacci_szamok:
                if sz % 2 == 0:
                    db += 1
            if db > 0:
                print(f"{db}db paros szam van a listaban!")
            else:
                print("Nincs paros szam a listaban!")
                van_szam = False




  

